# lora-skill

我的个人思维模式Skill，用于AI助手（如Marvis）模拟我的思考方式和对话风格。

## 内容

- **SKILL.md** - 核心技能文件，包含8个心智模型、9条决策启发式、完整表达DNA
- **meta.json** - Marvis技能元数据，包含触发词和配置
- **references/** - 原始调研材料，包括对话记录、写作、时间线等

## 心智模型

1. **第一性原理思维** - 从底层需求出发推演
2. **实践优先于理论** - 先快速实践出反馈，强调"动脑子，灵起来"
3. **成功三要素** - 努力+运气+自大
4. **四阶段决策流程** - 先问AI→知道AI会迎合→搜集网页→看国外大佬→统计→计划→执行
5. **思维树横向扩展** - 多目标优化，一个动作解决多个问题
6. **探索到底不停止** - 贼有探索心，不搞明白不罢休
7. **兴趣驱动社交** - 只跟感兴趣的人话唠
8. **拷问式共识达成** - 通过提问拷问+推荐答案达成共识

## 下载

直接下载zip [lora-skill.zip](https://github.com/lora-sys/lora-skills/raw/main/lora-skill.zip)

## 使用方式

1. 下载 `lora-skill.zip` 解压
2. 通过Marvis技能管理面板导入
3. 如果Marvis不支持直接导入，将解压后的文件放入Marvis的 `skills/market/lora/` 目录，确保 SKILL.md 权限为 644（可读）
4. 触发词：`lora`、`lora思维`、`lora模式`、`lora视角`、`lora决策`、`lora对话`、`lora拷问`
5. 激活后AI会模拟我的思考方式和对话风格

## GitHub

- 仓库：https://github.com/lora-sys/lora-skills
- 直接下载：https://github.com/lora-sys/lora-skills/raw/main/lora-skill.zip
- 作者：lora (22岁技术狂宅，西安，INFJ白羊座)
- GitHub账号：lora-sys

## 更新历史

- 2026-05-26: 创建skill，包含6个心智模型
- 2026-05-26: 新增"探索到底不停止"和"拷问式共识达成"模型
- 2026-05-26: 添加经典案例（学英语三全其美解法）